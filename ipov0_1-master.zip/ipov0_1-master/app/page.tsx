'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, Download, Upload } from 'lucide-react';
import CSVUploadForm from '@/components/csv-upload-form';
import CSVTable from '@/components/csv-table';
import LogConsole from '@/components/log-console';

export default function Home() {
  const [csvData, setCsvData] = useState<Record<string, string>[]>([]);
  const [applyId, setApplyId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleCsvUpload = (data: Record<string, string>[]) => {
    setCsvData(data);
    setError(null);
    setApplyId(null);
  };

  const handleDownloadTemplate = () => {
    const template = 'name,dp,username,password,pin,crn,units\nbasanta,13700,73058,password123,1234,12345678,100';
    const blob = new Blob([template], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'ipo-template.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const handleApplyIPO = async () => {
    if (csvData.length === 0) {
      setError('Please upload a CSV file first');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const newApplyId = `apply_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      setApplyId(newApplyId);

      // Trigger GitHub Actions workflow
      const response = await fetch('/api/dispatch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apply_id: newApplyId,
          csv_data: csvData,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to trigger workflow');
      }

      const result = await response.json();
      console.log('Workflow triggered:', result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      setApplyId(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleApplyIdChange = (newApplyId: string | null) => {
    setApplyId(newApplyId);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-cyan-50 to-teal-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-12 text-center">
          <div className="inline-block mb-4 px-4 py-2 bg-gradient-to-r from-blue-100 to-cyan-100 rounded-full border border-cyan-200">
            <span className="text-sm font-semibold text-cyan-700">Automated IPO Application</span>
          </div>
          <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-teal-600 bg-clip-text text-transparent mb-3">
            IPO Automation System
          </h1>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Streamline your IPO applications with intelligent automation. Upload your data and let our system handle the rest.
          </p>
        </div>

        {/* Error Alert */}
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Upload & Controls */}
          <div className="lg:col-span-1 space-y-6">
            {/* CSV Upload */}
            <Card className="border-blue-200 bg-white shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-cyan-50 border-b border-blue-100">
                <CardTitle className="text-blue-900">Upload CSV</CardTitle>
                <CardDescription>Import your IPO application data</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 pt-6">
                <CSVUploadForm onUpload={handleCsvUpload} />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleDownloadTemplate}
                  className="w-full bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download Template
                </Button>
              </CardContent>
            </Card>

            {/* Apply IPO */}
            {csvData.length > 0 && (
              <Card className="border-teal-200 bg-gradient-to-br from-teal-50 to-cyan-50 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader className="bg-gradient-to-r from-teal-100 to-cyan-100 border-b border-teal-200">
                  <CardTitle className="text-teal-900">Start Application</CardTitle>
                  <CardDescription className="text-teal-700">
                    {csvData.length} row{csvData.length !== 1 ? 's' : ''} ready to process
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <Button
                    onClick={handleApplyIPO}
                    disabled={isLoading}
                    className="w-full bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white font-semibold"
                  >
                    {isLoading ? 'Processing...' : 'Apply IPO'}
                    <Upload className="h-4 w-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Column - Data Display & Logs */}
          <div className="lg:col-span-2 space-y-6">
            {/* CSV Table */}
            {csvData.length > 0 && (
              <Card className="border-blue-200 shadow-lg">
                <CardHeader className="bg-gradient-to-r from-blue-50 to-cyan-50 border-b border-blue-100">
                  <CardTitle className="text-blue-900">CSV Data Preview</CardTitle>
                  <CardDescription>Showing uploaded data (sensitive columns hidden)</CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <CSVTable data={csvData} />
                </CardContent>
              </Card>
            )}

            {/* Log Console */}
            {applyId && (
              <Card className="border-cyan-200 shadow-lg">
                <CardHeader className="bg-gradient-to-r from-cyan-50 to-teal-50 border-b border-cyan-100">
                  <CardTitle className="text-cyan-900">Live Logs</CardTitle>
                  <CardDescription>Apply ID: <span className="font-mono text-cyan-700">{applyId}</span></CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <LogConsole 
                    applyId={applyId} 
                    onApplyIdChange={handleApplyIdChange}
                    csvData={csvData}
                  />
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
